/**
 * Contact form functionality for MS^2 Cafe website
 * Handles form submission and validation
 */

export function initContactForm() {
  const contactForm = document.getElementById('contact-form');
  const newsletterForm = document.getElementById('newsletter-form');
  
  if (contactForm) {
    contactForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      // Gather form data
      const formData = {
        name: contactForm.querySelector('#name').value,
        email: contactForm.querySelector('#email').value,
        phone: contactForm.querySelector('#phone').value,
        message: contactForm.querySelector('#message').value
      };
      
      // In a real application, you would send this data to a server
      console.log('Form submitted with data:', formData);
      
      // Show success message
      showFormMessage(contactForm, 'Your message has been sent successfully!');
      
      // Reset form
      contactForm.reset();
    });
  }
  
  if (newsletterForm) {
    newsletterForm.addEventListener('submit', (e) => {
      e.preventDefault();
      
      // Get email
      const email = newsletterForm.querySelector('input[type="email"]').value;
      
      // In a real application, you would send this to a server
      console.log('Newsletter signup:', email);
      
      // Show success message
      showFormMessage(newsletterForm, 'You have successfully subscribed to our newsletter!');
      
      // Reset form
      newsletterForm.reset();
    });
  }
  
  function showFormMessage(form, message) {
    // Check if message element already exists
    let messageElement = form.querySelector('.form-message');
    
    if (!messageElement) {
      // Create message element
      messageElement = document.createElement('div');
      messageElement.className = 'form-message';
      form.appendChild(messageElement);
      
      // Add styles for message
      const style = document.createElement('style');
      style.textContent = `
        .form-message {
          padding: 10px;
          margin-top: 16px;
          border-radius: 4px;
          background-color: var(--success);
          color: white;
          text-align: center;
          opacity: 0;
          transform: translateY(10px);
          transition: opacity 0.3s ease, transform 0.3s ease;
        }
        
        .form-message.active {
          opacity: 1;
          transform: translateY(0);
        }
      `;
      document.head.appendChild(style);
    }
    
    // Update message and show
    messageElement.textContent = message;
    messageElement.classList.add('active');
    
    // Hide message after 5 seconds
    setTimeout(() => {
      messageElement.classList.remove('active');
    }, 5000);
  }
}