// Main JavaScript file
import '../styles/main.css';
import '../styles/header.css';
import '../styles/sections.css';
import { initNavigation } from './navigation.js';
import { initMenuFilter } from './menu.js';
import { initScrollAnimations } from './animations.js';
import { initContactForm } from './contact.js';

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', () => {
  console.log('MS^2 Cafe website initialized');
  
  // Initialize all modules
  initNavigation();
  initMenuFilter();
  initScrollAnimations();
  initContactForm();
  
  // Back to top button functionality
  const backToTopButton = document.getElementById('back-to-top');
  
  window.addEventListener('scroll', () => {
    if (window.scrollY > 300) {
      backToTopButton.classList.add('visible');
    } else {
      backToTopButton.classList.remove('visible');
    }
  });
  
  backToTopButton.addEventListener('click', () => {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
});