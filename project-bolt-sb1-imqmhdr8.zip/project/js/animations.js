/**
 * Scroll animations for MS^2 Cafe website
 * Adds animations to elements as they enter the viewport
 */

export function initScrollAnimations() {
  // Function to check if an element is in viewport
  function isInViewport(element) {
    const rect = element.getBoundingClientRect();
    return (
      rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.8 &&
      rect.bottom >= 0
    );
  }
  
  // Elements to animate
  const elementsToAnimate = document.querySelectorAll('.section-header, .about-content, .feature, .menu-item, .offer, .gallery-item, .location-content, .contact-content');
  
  // Add animation classes when elements enter viewport
  function animateOnScroll() {
    elementsToAnimate.forEach(element => {
      if (isInViewport(element) && !element.classList.contains('animated')) {
        element.classList.add('animate-on-scroll', 'animated');
        element.style.animationDelay = `${Math.random() * 0.3}s`;
      }
    });
  }
  
  // Add CSS for scroll animations
  const style = document.createElement('style');
  style.textContent = `
    .animate-on-scroll {
      opacity: 0;
      transform: translateY(20px);
      animation: fadeInUp 0.6s ease forwards;
    }
    
    @keyframes fadeInUp {
      to {
        opacity: 1;
        transform: translateY(0);
      }
    }
  `;
  document.head.appendChild(style);
  
  // Run on scroll and initially
  window.addEventListener('scroll', animateOnScroll);
  animateOnScroll();
  
  // Image hover effect for gallery
  const galleryItems = document.querySelectorAll('.gallery-item');
  galleryItems.forEach(item => {
    item.addEventListener('mouseenter', () => {
      item.querySelector('img').style.transform = 'scale(1.1)';
    });
    
    item.addEventListener('mouseleave', () => {
      item.querySelector('img').style.transform = 'scale(1)';
    });
  });
}